pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Додаємо репозиторій для MQTT-бібліотек сюди:
        maven {
            url = uri("https://eclipse.org")
        }
    }
}

// Рядок нижче може відрізнятися назвою вашого проекту, залиште як тут або як було у вас
rootProject.name = "MyApplication"
include(":app")
