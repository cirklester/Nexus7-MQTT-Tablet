package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private TextView textClockTime;
    private TextView textClockDate;
    private LinearLayout layoutSensorsContainer;
    private SharedPreferences prefs;
    private MqttClient client;
    private Map<String, View> sensorViewsMap = new HashMap<String, View>();

    // Елементи таймера для годинника
    private final Handler clockHandler = new Handler();
    private final Runnable clockRunnable = new Runnable() {
        @Override
        public void run() {
            updateRealTimeClock();
            clockHandler.postDelayed(this, 1000); // Оновлюємо час кожну секунду
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ініціалізація нових текстових полів годинника
        textClockTime = (TextView) findViewById(R.id.textClockTime);
        textClockDate = (TextView) findViewById(R.id.textClockDate);

        layoutSensorsContainer = (LinearLayout) findViewById(R.id.layoutSensorsContainer);
        Button btnSettings = (Button) findViewById(R.id.btnSettings);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        // Запуск годинника
        clockHandler.post(clockRunnable);

        new GetWeatherTask().execute(prefs.getString("weather_city", "Kyiv"));
    }

    private void updateRealTimeClock() {
        try {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault());
            Date now = new Date();

            if (textClockTime != null) textClockTime.setText(timeFormat.format(now));
            if (textClockDate != null) textClockDate.setText(dateFormat.format(now));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        buildSensorListUI();
        startMqttThread();
    }

    @Override
    protected void onPause() {
        super.onPause();
        disconnectMqtt();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clockHandler.removeCallbacks(clockRunnable); // Зупиняємо таймер при закритті
    }

    private void buildSensorListUI() {
        layoutSensorsContainer.removeAllViews();
        sensorViewsMap.clear();
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 1; i <= 3; i++) {
            String name = prefs.getString("sensor_name_" + i, "");
            String topic = prefs.getString("sensor_topic_" + i, "");

            if (!topic.isEmpty()) {
                View rowView = inflater.inflate(R.layout.row_sensor, layoutSensorsContainer, false);
                TextView txtLocation = (TextView) rowView.findViewById(R.id.textSensorLocation);
                txtLocation.setText(name);

                if (name.toLowerCase().contains("вулиц") || i == 1) {
                    rowView.findViewById(R.id.layoutExtraData).setVisibility(View.VISIBLE);
                } else {
                    rowView.findViewById(R.id.layoutExtraData).setVisibility(View.GONE);
                }

                layoutSensorsContainer.addView(rowView);
                sensorViewsMap.put(topic, rowView);
            }
        }
    }

    private void startMqttThread() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    disconnectMqtt();

                    String serverUri = prefs.getString("mqtt_broker", "tcp://://hivemq.com");
                    String clientId = "Nexus7_" + System.currentTimeMillis();

                    client = new MqttClient(serverUri, clientId, new MemoryPersistence());
                    MqttConnectOptions options = new MqttConnectOptions();
                    options.setCleanSession(true);
                    options.setConnectionTimeout(15);
                    options.setKeepAliveInterval(60);

                    client.setCallback(new MqttCallback() {
                        @Override
                        public void connectionLost(Throwable cause) {
                            try { Thread.sleep(5000); } catch (Exception e) {}
                            startMqttThread();
                        }

                        @Override
                        public void messageArrived(String topic, MqttMessage message) throws Exception {
                            updateSensorData(topic, new String(message.getPayload()));
                        }

                        @Override
                        public void deliveryComplete(IMqttDeliveryToken token) {}
                    });

                    client.connect(options);

                    for (String topic : sensorViewsMap.keySet()) {
                        client.subscribe(topic, 0);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void updateSensorData(final String topic, final String payload) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                View rowView = sensorViewsMap.get(topic);
                if (rowView == null) return;

                TextView txtTemp = (TextView) rowView.findViewById(R.id.textTemperature);
                TextView txtBat = (TextView) rowView.findViewById(R.id.textBattery);
                TextView txtSig = (TextView) rowView.findViewById(R.id.textSignal);

                try {
                    JSONObject json = new JSONObject(payload);
                    if (json.has("temp")) txtTemp.setText(json.getString("temp") + "°C");
                    if (json.has("bat")) txtBat.setText("🔋 " + json.getString("bat") + "%");
                    if (json.has("rssi")) txtSig.setText("📶 " + json.getString("rssi") + "dBm");
                } catch (Exception e) {
                    txtTemp.setText(payload + "°C");
                }
            }
        });
    }

    private void disconnectMqtt() {
        try {
            if (client != null && client.isConnected()) {
                client.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class GetWeatherTask extends AsyncTask<String, Void, String[]> {
        @Override
        protected String[] doInBackground(String... params) {
            try { Thread.sleep(300); } catch (InterruptedException e) {}
            return new String[]{"Сьогодні: +18°C | Хмарно", "Пн: +18° | Вт: +19° | Ср: +16° | Чт: +17° | Пт: +19°"};
        }

        @Override
        protected void onPostExecute(String[] result) {
            if (result != null && result.length >= 2) {
                TextView txtCurrent = (TextView) findViewById(R.id.textCurrentWeather);
                TextView txtWeek = (TextView) findViewById(R.id.textWeekWeather);

                // Вказуємо індекси масиву [0] та [1] замість усього об'єкта result
                if (txtCurrent != null) txtCurrent.setText(result[0]);
                if (txtWeek != null) txtWeek.setText(result[1]);
            }
        }
    }
}
